uniform sampler2D tex;
uniform float sampleDist;
uniform float sampleStrength;

void main()
{
    vec2 texCoord = gl_TexCoord[0].st;
    vec2 dir = vec2(0.5, 0.5) - texCoord;
    float dist = length(dir);
    dir = normalize(dir);

    vec4 color = texture2D(tex, texCoord);
    vec4 sum = color;
    sum += texture2D(tex, texCoord + dir * (-0.08) * sampleDist);
    sum += texture2D(tex, texCoord + dir * (-0.05) * sampleDist);
    sum += texture2D(tex, texCoord + dir * (-0.03) * sampleDist);
    sum += texture2D(tex, texCoord + dir * (-0.02) * sampleDist);
    sum += texture2D(tex, texCoord + dir * (-0.01) * sampleDist);
    sum += texture2D(tex, texCoord + dir * 0.01 * sampleDist);
    sum += texture2D(tex, texCoord + dir * 0.02 * sampleDist);
    sum += texture2D(tex, texCoord + dir * 0.03 * sampleDist);
    sum += texture2D(tex, texCoord + dir * 0.05 * sampleDist);
    sum += texture2D(tex, texCoord + dir * 0.08 * sampleDist);
    sum /= 11.0;

    float t = clamp(dist * sampleStrength, 0.0, 1.0);
    gl_FragColor = mix(color, sum, t);
}
