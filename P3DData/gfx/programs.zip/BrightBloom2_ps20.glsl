uniform sampler2D RT;

void main()
{
    vec4 tex = texture2D(RT, gl_TexCoord[0].st);
    // Only pixels brighter than 0.875 contribute. The gain is half of the
    // original *8 so a solid white ball glows without turning into a flat light.
    gl_FragColor = max(vec4(0.0), (tex - 0.875) * 4.0);
}
