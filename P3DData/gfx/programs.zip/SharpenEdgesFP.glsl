uniform sampler2D RT;
uniform vec2 vTexelSize;
uniform float Sharpen;

varying vec2 uv0;

void main()
{
	vec4 color = 9.0 * texture2D(RT, uv0);
	color -= texture2D(RT, uv0 + vTexelSize * vec2(-Sharpen, -Sharpen));
	color -= texture2D(RT, uv0 + vTexelSize * vec2( 0.0,     -Sharpen));
	color -= texture2D(RT, uv0 + vTexelSize * vec2( Sharpen, -Sharpen));
	color -= texture2D(RT, uv0 + vTexelSize * vec2(-Sharpen,  0.0));
	color -= texture2D(RT, uv0 + vTexelSize * vec2( Sharpen,  0.0));
	color -= texture2D(RT, uv0 + vTexelSize * vec2(-Sharpen,  Sharpen));
	color -= texture2D(RT, uv0 + vTexelSize * vec2( 0.0,      Sharpen));
	color -= texture2D(RT, uv0 + vTexelSize * vec2( Sharpen,  Sharpen));
	gl_FragColor = color;
}
