varying vec2 uv0;

void main()
{
	gl_Position = ftransform();
	vec2 inPos = sign(gl_Vertex.xy);
	uv0 = (vec2(inPos.x, -inPos.y) + 1.0) * 0.5;
}
