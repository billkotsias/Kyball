uniform vec4 ambient;
uniform vec4 matDif;
uniform sampler2D dMap;
uniform sampler2D aoMap;

varying vec2 oUV;

void main()
{
    gl_FragColor = texture2D(dMap, oUV) * texture2D(aoMap, oUV)
        * vec4(ambient.rgb, 1.0) * vec4(matDif.rgb, 1.0);
}
