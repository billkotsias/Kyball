attribute vec4 vertex;
attribute vec4 uv0;

uniform mat4 wvpMat;

varying vec2 oUV;

void main()
{
    gl_Position = wvpMat * vertex;
    oUV = uv0.xy;
}
