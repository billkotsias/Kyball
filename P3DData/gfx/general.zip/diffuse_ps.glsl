uniform vec4 lightDif0;
uniform vec4 lightPos0;
uniform vec4 lightAtt0;
uniform vec4 lightSpec0;
uniform vec4 matDif;
uniform vec4 matSpec;
uniform float matShininess;
uniform vec3 camPos;
uniform vec4 spotlightParams;
uniform mat4 iTWMat;
uniform sampler2D diffuseMap;
uniform sampler2D specMap;
uniform sampler2D normalMap;

varying vec2 oUV;
varying vec3 oWp;
varying vec3 oN;
varying vec3 oT;
varying vec3 oB;
varying vec3 oSdir;

void main()
{
    vec3 toLight = lightPos0.xyz - (lightPos0.w * oWp);
    vec3 ld0 = normalize(toLight);

    // lightAtt0.x is the light range. Zero means no distance falloff.
    // Past the range the original quadratic term goes negative; keep it at zero.
    float range = lightAtt0.x;
    float la = 1.0;
    if (range > 0.0)
    {
        float lightDist = length(lightPos0.xyz - oWp) / range;
        la = max(1.0 - lightDist * lightDist, 0.0);
    }

    vec3 tsNormal = texture2D(normalMap, oUV).xyz * 2.0 - 1.0;
    vec3 nObj;
    if (dot(oT, oT) > 1e-8)
        nObj = mat3(oT, oB, oN) * tsNormal;
    else
        nObj = oN;
    vec3 nWorld = normalize(mat3(iTWMat) * nObj);

    float ndotl = max(dot(ld0, nWorld), 0.0);

    float spot;
    if (spotlightParams.x == 1.0 && spotlightParams.y == 0.0
        && spotlightParams.z == 0.0 && spotlightParams.w == 1.0)
        spot = 1.0;
    else
        spot = clamp((dot(ld0, normalize(-oSdir)) - spotlightParams.y)
            / (spotlightParams.x - spotlightParams.y), 0.0, 1.0);

    vec3 camDir = normalize(camPos - oWp);
    vec3 halfVec = normalize(ld0 + camDir);
    float ndh = max(dot(nWorld, halfVec), 0.0);
    float specular = ndh > 0.0 ? pow(ndh, matShininess) : 0.0;

    vec4 diffuseTex = texture2D(diffuseMap, oUV);
    vec4 specTex = texture2D(specMap, oUV);

    vec3 diffuseContrib = ndotl * lightDif0.rgb * diffuseTex.rgb * matDif.rgb;
    vec3 specularContrib = specular * lightSpec0.rgb * specTex.rgb * matSpec.rgb;
    vec3 light0C = (diffuseContrib + specularContrib) * la * spot;

    gl_FragColor = vec4(light0C, diffuseTex.a);
}
