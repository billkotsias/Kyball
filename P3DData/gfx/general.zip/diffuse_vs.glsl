attribute vec4 vertex;
attribute vec3 normal;
attribute vec3 tangent;
attribute vec4 uv0;

uniform mat4 wMat;
uniform mat4 wvpMat;
uniform vec4 spotlightDir;

varying vec2 oUV;
varying vec3 oWp;
varying vec3 oN;
varying vec3 oT;
varying vec3 oB;
varying vec3 oSdir;

void main()
{
    vec4 worldPos = wMat * vertex;
    gl_Position = wvpMat * vertex;
    oUV = uv0.xy;
    oWp = worldPos.xyz;
    oN = normal;
    oT = tangent;
    oB = cross(tangent, normal);
    oSdir = (wMat * spotlightDir).xyz;
}
